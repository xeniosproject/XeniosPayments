<?php
	$file = './httpres.txt';
	$json_ipn_res = file_get_contents('php://input');
	file_put_contents($file, $json_ipn_res);

	require_once( 'includes/configure.php' );
	require_once( 'includes/application_top.php' );
	require_once(__DIR__.'/includes/modules/payment/forgingblock/lib/Forgingblock.php');

	if (empty($json_ipn_res)){
		echo "Data Missinging";
		exit;
	}

	$nofify_ar =  json_decode($json_ipn_res, true);

	$invoice_id = $nofify_ar['id'];
	if (empty($invoice_id)){
		echo "Data Missinging";
		exit;
	}

	$fbconf = getfbConf();

	$trmode = ($fbconf['MODULE_PAYMENT_FORGINGBLOCK_TESTMODE'] == 'Live') ? 'live' : 'test';  
	$forgingblockAPI = new ForgingblockAPI($trmode);	 
	$forgingblockAPI->SetValue('trade', $fbconf['MODULE_PAYMENT_FORGINGBLOCK_TRADEID']);
	$forgingblockAPI->SetValue('token', $fbconf['MODULE_PAYMENT_FORGINGBLOCK_TOKEN']);		
	$forgingblockAPI->SetValue('invoice', $invoice_id);		
		
	$resar = $forgingblockAPI->CheckInvoiceStatus();
	$order_id = $resar['order'];		
	$payment_status = $forgingblockAPI->GetInvoiceStatus();
	if (!empty($order_id)){
		$newstatus = $fbconf['MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID'];
		if ($payment_status == 'confirmed') $newstatus = $fbconf['MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID'];
		if ($payment_status == 'paid') $newstatus = $fbconf['MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID'];		
		if ($payment_status == 'complete') $newstatus = $fbconf['MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID'];				
		if ($payment_status == 'expired') $newstatus = $fbconf['MODULE_PAYMENT_FORGINGBLOCK_EXP_ORDER_STATUS_ID'];				
		
		$comments = 'payment status :'.$payment_status.' , Invoice Id: '.$invoice_id;
 		$ordupdatar = array(array('fieldName' => 'orders_id', 'value' => $order_id, 'type' => 'integer'),
            array('fieldName' => 'orders_status_id', 'value' => $newstatus, 'type' => 'integer'),
            array('fieldName' => 'date_added', 'value' => 'now()', 'type' => 'noquotestring'),
            array('fieldName' => 'comments', 'value' => $comments, 'type' => 'string'),
            array('fieldName' => 'customer_notified', 'value' => 0, 'type' => 'integer'));
		
        $db->perform(TABLE_ORDERS_STATUS_HISTORY, $ordupdatar);
		
        $db->Execute("UPDATE " . TABLE_ORDERS . " SET `orders_status` = '" . (int)$newstatus
            . "' WHERE `orders_id` = '" . (int)$order_id . "'");
		echo "OK";
		
	}
		

 function getfbConf()
    {
        global $db;
        $query = $db->Execute("SELECT configuration_key,configuration_value FROM " . TABLE_CONFIGURATION
            . " WHERE configuration_key LIKE 'MODULE\_PAYMENT\_FORGINGBLOCK\_%'");
        if ($query->RecordCount() === 0) {            
			return false;
        }
        while (!$query->EOF) {
            $fbconf[$query->fields['configuration_key']] = $query->fields['configuration_value'];
            $query->MoveNext();
        }
	 return $fbconf;
    }

?>