<?php
   require_once(__DIR__.'/forgingblock/lib/Forgingblock.php');

  class forgingblock {
    var $code, $title, $description, $enable, $form_action_url, $public_title;

    function forgingblock() {
      global $order;		

      $this->code = 'forgingblock';
      $this->title = MODULE_PAYMENT_FORGINGBLOCK_TEXT_TITLE;
      $this->public_title = MODULE_PAYMENT_FORGINGBLOCK_TEXT_PUBLIC_TITLE;
      $this->description = MODULE_PAYMENT_FORGINGBLOCK_TEXT_DESCRIPTION;
      $this->sort_order = MODULE_PAYMENT_FORGINGBLOCK_SORT_ORDER;
      $this->enabled = ((MODULE_PAYMENT_FORGINGBLOCK_STATUS == 'True') ? true : false);

      
		
		if (MODULE_PAYMENT_FORGINGBLOCK_STATUS == 'True' && (MODULE_PAYMENT_FORGINGBLOCK_TOKEN == '')) {
      		$this->title .=  '<span class="alert"> (Not Configured)</span>';
    	} elseif (MODULE_PAYMENT_FORGINGBLOCK_TESTMODE == 'Test') {
      		$this->title .= '<span class="alert"> (in Testing mode)</span>';
    	} 		
		
		
	   if (defined('MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID') && (int)MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID > 0) {
        $this->order_status = MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID;
       }
		
		
		
		$this->form_action_url = tep_href_link('ext/modules/payment/forgingblock/pay.php');
		
		if (is_object($order)) $this->update_status();	
    }

// class methods
    function update_status() {
      global $order;

      if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_FORGINGBLOCK_ZONE > 0) ) {
        $check_flag = false;
        $check_query = tep_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_FORGINGBLOCK_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
        while ($check = tep_db_fetch_array($check_query)) {
          if ($check['zone_id'] < 1) {
            $check_flag = true;
            break;
          } elseif ($check['zone_id'] == $order->billing['zone_id']) {
            $check_flag = true;
            break;
          }
        }

        if ($check_flag == false) {
          $this->enabled = false;
        }
      }
    }

  function javascript_validation() {
    return '';
  }
  
  function selection() {
      return array('id' => $this->code,
                   'module' => $this->title);
  }
  
	
  function pre_confirmation_check() {    
    return true;
  }
  
	
  function confirmation() {	
    return array();
  }
	
   
  function process_button() {        
	  global $cartID, $currency, $order;
	  $payparam = array("orderid"=>$cartID,
		  'amount' => round($order->info['total'], 2),
		  "currency"=>$currency
	  );
	  foreach ($payparam as $key => $value) {
        $process_button_string .= tep_draw_hidden_field($key, $value);
      }
    return $process_button_string;
	  
  }
  /**
   * Store the CC info to the order and process any results that come back from the payment gateway
   *
   */
  function before_process() {
	  echo "test";
	  exit;
	  return true;
  }

  
  function after_process() {	
	  echo "test";
	  exit;
	tep_session_unregister('cartID');
    return false;
  }
    function check() {
      if (!isset($this->_check)) {
        $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_FORGINGBLOCK_STATUS'");
        $this->_check = tep_db_num_rows($check_query);
      }
      return $this->_check;
    }

    function install() {
		
		
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Xenios Payments Cryptocurrency Gateway osCommerce ', 'MODULE_PAYMENT_FORGINGBLOCK_STATUS', 'False', 'Do you want to accept payments?', '6', '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
		
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Trade ID', 'MODULE_PAYMENT_FORGINGBLOCK_TRADEID', '', 'Trade ID assigned in Xenios Payments Cryptocurrency Gateway osCommerce', '6', '2', now())");
		
	  tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, 	configuration_group_id, sort_order, date_added) values ('Token', 'MODULE_PAYMENT_FORGINGBLOCK_TOKEN', '', 'Token assigned in Xenios Payments Cryptocurrency Gateway osCommerce', '6', '2', now())");		
		
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) values ('Sort order of display.', 'MODULE_PAYMENT_FORGINGBLOCK_SORT_ORDER', '0', 'Sort order of display. Lowest is displayed first.', '6', '0', now())");
		
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added) values ('Payment Zone', 'MODULE_PAYMENT_FORGINGBLOCK_ZONE', '0', 'If a zone is selected, only enable this payment method for that zone.', '6', '2', 'tep_get_zone_class_title', 'tep_cfg_pull_down_zone_classes(', now())");
		
	  tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Environment', 'MODULE_PAYMENT_FORGINGBLOCK_TESTMODE', 'Test', 'Environment', '6', '1', 'tep_cfg_select_option(array(\'Test\', \'Live\'), ', now())");
		
		
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order New Status', 'MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID', '1', 'Set the status of new orders', '6', '0', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");
		
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Paid Status', 'MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID', '2', 'Set the status of paid order', '6', '0', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");		
		
      tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added) values ('Set Order Expired Status', 'MODULE_PAYMENT_FORGINGBLOCK_EXP_ORDER_STATUS_ID', '1', 'Set the status of Expired orders', '6', '0', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now())");	
		
      		
    }

    function remove() {
      tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "')");
    }

    function keys() {
      return array('MODULE_PAYMENT_FORGINGBLOCK_STATUS',
            'MODULE_PAYMENT_FORGINGBLOCK_SORT_ORDER',
            'MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID',
		    'MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID',				 
		    'MODULE_PAYMENT_FORGINGBLOCK_EXP_ORDER_STATUS_ID',				 				 
            'MODULE_PAYMENT_FORGINGBLOCK_ZONE',
            'MODULE_PAYMENT_FORGINGBLOCK_TRADEID',
            'MODULE_PAYMENT_FORGINGBLOCK_TOKEN',            
            'MODULE_PAYMENT_FORGINGBLOCK_TESTMODE');
    }

	  
  }
?>
