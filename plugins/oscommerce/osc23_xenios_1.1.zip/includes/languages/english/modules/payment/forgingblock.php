<?php
	define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_PUBLIC_TITLE', 'Xenios Payments Cryptocurrency Gateway osCommerce');
	define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_TITLE', 'Xenios Payments Cryptocurrency Gateway osCommerce');
	define('MODULE_PAYMENT_FORGINGBLOCK_TEXT_DESCRIPTION', 'Pay using Xenios Payments Cryptocurrency Gateway osCommerce');
?>
