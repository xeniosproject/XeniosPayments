<?php

	chdir('../../../../');	
	require_once('includes/modules/payment/forgingblock/lib/Forgingblock.php');	
	require_once( 'includes/application_top.php' );
	
	$json_ipn_res = file_get_contents('php://input');

	if (empty($json_ipn_res)){
		echo "Data Missinging";
		exit;
	}

	$nofify_ar =  json_decode($json_ipn_res, true);

	$invoice_id = $nofify_ar['id'];
	if (empty($invoice_id)){
		echo "Data Missinging";
		exit;
	}

	
	$trmode = (MODULE_PAYMENT_FORGINGBLOCK_TESTMODE == 'Live') ? 'live' : 'test';  
	$forgingblockAPI = new ForgingblockAPI($trmode);	 
	$forgingblockAPI->SetValue('trade', MODULE_PAYMENT_FORGINGBLOCK_TRADEID);
	$forgingblockAPI->SetValue('token', MODULE_PAYMENT_FORGINGBLOCK_TOKEN);		
	$forgingblockAPI->SetValue('invoice', $invoice_id);		
		
	$resar = $forgingblockAPI->CheckInvoiceStatus();

	$order_id = $resar['order'];		
	$payment_status = $forgingblockAPI->GetInvoiceStatus();
	if (!empty($order_id)){
		$newstatus = MODULE_PAYMENT_FORGINGBLOCK_ORDER_STATUS_ID;
		if ($payment_status == 'confirmed') $newstatus = MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID;
		if ($payment_status == 'paid') $newstatus = MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID;		
		if ($payment_status == 'complete') $newstatus = MODULE_PAYMENT_FORGINGBLOCK_PAID_ORDER_STATUS_ID;				
		if ($payment_status == 'expired') $newstatus = MODULE_PAYMENT_FORGINGBLOCK_EXP_ORDER_STATUS_ID;				
		
		$comments = 'payment status :'.$payment_status.' , Invoice Id: '.$invoice_id;
		
		$sql_data_array1 = array('orders_id' => $order_id,
                                    'orders_status_id' => $newstatus,
                                    'date_added' => 'now()',
                                    'customer_notified' => '1',
                                    'comments' => $comments);

            tep_db_perform(TABLE_ORDERS_STATUS_HISTORY, $sql_data_array1);			
 		
		
		tep_db_query("update " . TABLE_ORDERS . " set orders_status = '" . $newstatus . "', last_modified = now() where orders_id = '" . (int)$order_id . "'");
		
        
		echo "OK";
		
	}
		

 

?>