<?php

namespace ForgingBlock\Payment\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

}