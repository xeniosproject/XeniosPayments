<?php


namespace ForgingBlock\Payment\Block;

class Redirect extends \Magento\Framework\View\Element\Template
{
    
    protected $_paymentMethodCode = 'forgingblock';

    
    protected $_paymentData = null;

    
    protected $_orderFactory;

    
    protected $_checkoutSession;

    
    protected $_logger;

    public function __construct(
    	\Magento\Framework\View\Element\Template\Context $context,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Payment\Helper\Data $paymentData,
        \Psr\Log\LoggerInterface $logger,
        array $data = []
    ) {
    	$this->_logger = $logger;
    	$this->_orderFactory = $orderFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->_paymentData = $paymentData;
        parent::__construct($context, $data);
    }

    
    protected function _getCheckoutSession()
    {
        return $this->_checkoutSession;
    }
    
    public function getFormAction()
    {		
        return $this->_paymentData->getMethodInstance($this->_paymentMethodCode)->getUrl();
    }
}