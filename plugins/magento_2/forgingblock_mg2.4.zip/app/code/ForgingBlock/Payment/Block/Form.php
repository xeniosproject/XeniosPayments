<?php
namespace ForgingBlock\Payment\Block;

class Form extends \Magento\Payment\Block\Form
{
    protected $_template = 'ForgingBlock_Payment::form.phtml';
}