<?php

namespace ForgingBlock\Payment\Controller\Standard;

require_once(__DIR__.'/../../Model/lib/Forgingblock.php');

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Notify extends Action implements CsrfAwareActionInterface
{
	
    protected $_checkoutSession;

    
    protected $_orderFactory;

    protected $_quoteFactory;

    protected $_order;


    protected $_logger;

	public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,		
        \Psr\Log\LoggerInterface $logger,
        \Magento\Quote\Model\QuoteFactory $quoteFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_orderFactory = $orderFactory;
        $this->_logger = $logger;
        $this->_quoteFactory = $quoteFactory;
        parent::__construct($context);
    }

   
    protected function _getCheckout()
    {
        return $this->_checkoutSession;
    }

    protected function _getOrder($incrementId= null)
    {
        if (!$this->_order) {
            $incrementId = $incrementId ? $incrementId : $this->_getCheckout()->getLastRealOrderId();
            $this->_order = $this->_orderFactory->create()->loadByIncrementId($incrementId);
        }
        return $this->_order;
    }


    public function execute()
    {
		$json_ipn_res = file_get_contents('php://input');			
		
		if (empty($json_ipn_res)){
			echo "Data Missing";
			exit;
		}
		
		$nofify_ar =  json_decode($json_ipn_res, true);
		$invoice_id = $nofify_ar['id'];
		if (empty($invoice_id)){
			echo "Data Missing-invoice_id";
			exit;
		}
		
		
		
		if (empty($_GET['orderid'])){
			echo "Data Missing - Orderid";
			exit;
		}
		else $orderid = $_GET['orderid'];
		
		$order = $this->_getOrder($orderid);	
		$paymentInst = $order->getPayment()->getMethodInstance();
		
				
		$trmode = ($paymentInst->getConfigData('pgmode') == '0') ? 'live' : 'test';  	
		$forgingblockAPI = new \ForgingblockAPI($trmode);	 
		$forgingblockAPI->SetValue('trade', $paymentInst->getConfigData('pgtrade_id'));	   
		$forgingblockAPI->SetValue('token', $paymentInst->getConfigData('pgtoken'));
		$forgingblockAPI->SetValue('invoice', $invoice_id);		
		
		$resar = $forgingblockAPI->CheckInvoiceStatus();
		$order_id = $resar['order'];		
		$payment_status = $forgingblockAPI->GetInvoiceStatus();
		if (!empty($order_id)){
			
			if ($payment_status == 'confirmed') $newstatus = $paymentInst->getConfigData('corder_status');
			if ($payment_status == 'paid') $newstatus = $paymentInst->getConfigData('corder_status');		
			if ($payment_status == 'complete') $newstatus = $paymentInst->getConfigData('corder_status');
			if ($payment_status == 'expired') $newstatus = $paymentInst->getConfigData('eorder_status');
			
			if ($newstatus == $paymentInst->getConfigData('corder_status')) {				
		        $payment = $order->getPayment();
	        	$payment->setTransactionId(microtime(true));
    		    $transaction = $payment->addTransaction(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_PAYMENT, null, false);						
	        	$transaction->setParentTxnId($invoice_id);				
		        $transaction->setIsClosed(1);										
				$order->setStatus($newstatus);
		        $transaction->save();
		        $order->save();			
			}
			else {
				$order->setStatus($payment_status);
				$order->save();			
			}
		}
		
		echo "OK";
		exit;
    }
	

	public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    /**
     * @inheritDoc
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}	


