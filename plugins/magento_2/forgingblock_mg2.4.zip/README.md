# ForgingBlock Magento 2 Payment Module

## Installation

1. Signup for an account at [ForgingBlock](https://forgingblock.io/)
2. Create an API Key (Pair Code) by going to the Settings tab in the ForgingBlock Commerce dashboard.
3. Download zip archive from release page and unzip
4. Copy content of src folder to the root of your magento2's installation. 
5. Run set of the commands with `magento` binary (located in `bin` folder inside magento installation root)  
   `magento module:enable ForgingBlock_Payment --clear-static-content`  
   `magento setup:upgrade`  
   `magento setup:static-content:deploy -f`  
   `magento cache:clean`  
6. Log in to admin area
6. Go to Stores -> Configuration -> Sales -> Payment Methods -> ForgingBlock Cryptocurrency Gateway Magento 
7. In plugin settings near Test Mode, select No (main net) or Yes (test net)
8. Type in your trade agreement in `Trade ID` and `token` inside Token 
   (those details are provided to you after every new store creation in the response and inside email)   
9. Click `Save config` Button

# Integrate with other e-commerce platforms
[ForgingBlock Integrations](https://forgingblock.io/plugin)
