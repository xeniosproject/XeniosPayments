# Xenios Payments Cryptocurrency Gateway PrestaShop 

## Installation

1. Signup for an account at [ForgingBlock](https://forgingblock.io/)
2. Create an API Key (Pair Code) by going to the Settings tab in the ForgingBlock Commerce dashboard.
3. Download zip archive from release page 
4. Copy content of src folder to the root of your Prestashop's `modules/` folder 
4. In PrestaShop admin panel select `Modules -> Module Catalog -> Install a module` and upload zip archive
5. After Installation click `Configure` or you could find plugin in `Modules -> Module Manager -> xenios` and click `Configure`
6. In plugin settings near API URL, select https://api.forgingblock.io (MainNet) or https://api-demo.forgingblock.io (TestNet)
7. You can create Pairing Code [here](https://forgingblock.io/#create-pairing), Copy `pairing` value you received and click `Pair`  


# Integrate with other e-commerce platforms
[ForgingBlock Integrations](https://forgingblock.io/plugin)