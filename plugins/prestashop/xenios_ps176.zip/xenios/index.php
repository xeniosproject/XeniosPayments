<?php				    	
header("Location: ../");
exit;