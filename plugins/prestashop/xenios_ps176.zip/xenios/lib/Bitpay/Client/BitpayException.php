<?php 

namespace Bitpay\Client;

class BitpayException extends \Exception
{

}
