<?php
define("BTCPAY_VERSION", "0.0.1");
$autoloader_param = __DIR__ . '/../../lib/Bitpay/Autoloader.php';

if (!defined('_PS_VERSION_'))
    exit;

// Load up the BitPay library
if (true === file_exists($autoloader_param) &&
    true === is_readable($autoloader_param))
{
  if(false === class_exists("Bitpay\Autoloader")){
    require_once $autoloader_param;
    \Bitpay\Autoloader::register();
  }
} else {
    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was not installed correctly or the files are corrupt. Please make sure you have correct folder user rights and have all required PHP extensions installed');
}

// Exist for quirks in object serialization...
if (false === class_exists('Bitpay\PrivateKey')) {
    include_once(__DIR__ . '/../../lib/Bitpay/PrivateKey.php');
}

if (false === class_exists('Bitpay\PublicKey')) {
    include_once(__DIR__ . '/../../lib/Bitpay/PublicKey.php');
}

if (false === class_exists('Bitpay\Token')) {
    include_once(__DIR__ . '/../../lib/Bitpay/Token.php');
}


class xeniosNotificationModuleFrontController extends ModuleFrontController {
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess() {
		
		$post = file_get_contents("php://input");
		
		$json = json_decode($post, true);		
		
		$Xenios = new Xenios();		
		$this->api_url = Configuration::get( 'XENIOS_URL' );
		$this->api_key = $Xenios->btcpay_decrypt(Configuration::get( 'XENIOS_KEY' ));				
		$this->api_pub = $Xenios->btcpay_decrypt(Configuration::get( 'XENIOS_PUB' ));		
		$this->api_token = $Xenios->btcpay_decrypt(Configuration::get( 'XENIOS_TOKEN' ));
			
		if(true === array_key_exists('event', $json) && true === array_key_exists('data', $json)) // extended notification type
         {
			
            $event = $json['event'];
            $json = $json['data'];
         }
        

		if (true === empty($json)) {                
                error_log('[Error] Fbuni Woocommerce plugin received an invalid JSON payload sent to IPN handler: ' . $post);                			
				exit;
            } 

            if (false === array_key_exists('id', $json)) {                
                error_log('[Error] Fbuni Woocommerce plugin did not receive an invoice ID present in JSON payload: ' . var_export($json, true));
				exit;              
            } 

            if (false === array_key_exists('url', $json)) {
                error_log('[Error] Fbuni Woocommerce plugin did not receive an invoice URL present in JSON payload: ' . var_export($json, true));
                exit;
           } 
		
		$client = new \Bitpay\Client\Client();
		
		if (false === isset($client) && true === empty($client)) {
                         throw new \Exception('The Fbuni Woocommerce payment plugin was called to handle an IPN but could not instantiate a client object. Cannot continue!');
            } 
            
		
            $url = $this->api_url;
            $client->setUri($url);            

            $curlAdapter = new \Bitpay\Client\Adapter\CurlAdapter();

            if (false === isset($curlAdapter) && true === empty($curlAdapter)) {
                
                throw new \Exception('The Fbuni Woocommerce payment plugin was called to handle an IPN but could not instantiate a CurlAdapter object. Cannot continue!');
            } 

            		
            $client->setAdapter($curlAdapter);
		
		            if (false === empty($this->api_key)) {
                $client->setPrivateKey($this->api_key);
            } else {
                $this->log('    [Error] The Fbuni Woocommerce payment plugin was called to handle an IPN but could not set client->setPrivateKey to this->api_key. The empty() check failed!');
                throw new \Exception('The Fbuni Woocommerce payment plugin was called to handle an IPN but could not set client->setPrivateKey to this->api_key. The empty() check failed!');
            }

            if (false === empty($this->api_pub)) {
                $client->setPublicKey($this->api_pub);
            } else {
                
                throw new \Exception('The Fbuni Woocommerce payment plugin was called to handle an IPN but could not set client->setPublicKey to this->api_pub. The empty() check failed!');
            }

            if (false === empty($this->api_token)) {
                $client->setToken($this->api_token);
            } else {
                
                throw new \Exception('The Fbuni Woocommerce payment plugin was called to handle an IPN but could not set client->setToken to this->api_token. The empty() check failed!');
            }

            

            // Fetch the invoice from BitPay's server to update the order
            try {
                $invoice = $client->getInvoice($json['id']);

                if (true === isset($invoice) && false === empty($invoice)) {
                    
                } else {
                    error_log('[Error] The IPN check did not pass!');
					exit;                    
                }
            } catch (\Exception $e) {
                $error_string = 'IPN Check: Can\'t find invoice ' . $json['id'];
                error_log("    [Error] $error_string");               								
				error_log("    [Error] ".$e->getMessage());
				exit;                                    
            }

            $order_id = $invoice->getOrderId();
			$amount = $invoice->getprice();
			
		
			
            $responseData = json_decode($client->getResponse()->getBody());

            if (false === isset($order_id) && true === empty($order_id)) {                
                throw new \Exception('The Fbuni Woocommerce payment plugin was called to process an IPN message but could not obtain the order ID from the invoice. Cannot continue!');
            } 
		
		
		$checkStatus = $invoice->getStatus();		
		
		$paid_status = 	empty(Configuration::get( 'XENIOS_PAIDST' )) ? 11 : Configuration::get( 'XENIOS_PAIDST' );		
		$complete_status = empty(Configuration::get( 'XENIOS_COMPLETEST' )) ? 2 : Configuration::get( 'XENIOS_COMPLETEST' );	
		$confirmed_status = empty(Configuration::get( 'XENIOS_CONFIRMRFST' )) ? 2 : Configuration::get( 'XENIOS_CONFIRMRFST' );			
		$invalid_status = empty(Configuration::get( 'XENIOS_INVALIDST' )) ? 8 : Configuration::get( 'XENIOS_INVALIDST' );		
		$expired_status = empty(Configuration::get( 'XENIOS_EXPIREDST' )) ? 8 : Configuration::get( 'XENIOS_EXPIREDST' );	
		$event_invoice_paidAfterExpiration = empty(Configuration::get( 'XENIOS_PAIDEXPIREDST' )) ? 8 : Configuration::get( 'XENIOS_PAIDEXPIREDST' );
		$event_invoice_expiredPaidPartial = empty(Configuration::get( 'XENIOS_PARTEXPIREDST' )) ? 8 : Configuration::get( 'XENIOS_PARTEXPIREDST' );	
		if (empty($event)) $event = "";
		
		if($event === "")
            {
				
                switch ($checkStatus) {

                    case 'paid':                     				
                        	$Xenios->setOrderStatus($order_id, $paid_status) ;
                        break;
                    
                    case 'confirmed':
						$Xenios->setOrderStatus($order_id, $confirmed_status) ;                        
                        break;
                    case 'complete':
						$Xenios->setOrderStatus($order_id, $complete_status) ;                                                
                        break;
                    
                    case 'invalid':

						$Xenios->setOrderStatus($order_id, $invalid_status) ;                                                                       
                        break;

                    case 'expired':
						$Xenios->setOrderStatus($order_id, $expired_status) ;                        
                        break;                    
                    default:

                        error_log('    [Info] IPN response is an unknown message type. See error message below:');
                        $error_string = 'Unhandled invoice status: ' . $invoice->getStatus();
                        error_log("    [Warning] $error_string");
                }
                
            }
            else //  is an event				
            {						
						                
                if ($event['code'] === 1009)
                {
                    $Xenios->setOrderStatus($order_id, $event_invoice_paidAfterExpiration) ;  
                }
                if ($event['code'] === 2000)
                {
                    $Xenios->setOrderStatus($order_id, $event_invoice_expiredPaidPartial) ;                      
                }
            }
		
		exit;
		
	}
}
