<?php
define("BTCPAY_VERSION", "0.0.1");
$autoloader_param = __DIR__ . '/../../lib/Bitpay/Autoloader.php';

if (!defined('_PS_VERSION_'))
    exit;

// Load up the BitPay library
if (true === file_exists($autoloader_param) &&
    true === is_readable($autoloader_param))
{
  if(false === class_exists("Bitpay\Autoloader")){
    require_once $autoloader_param;
    \Bitpay\Autoloader::register();
  }
} else {
    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was not installed correctly or the files are corrupt. Please make sure you have correct folder user rights and have all required PHP extensions installed');
}

// Exist for quirks in object serialization...
if (false === class_exists('Bitpay\PrivateKey')) {
    include_once(__DIR__ . '/../../lib/Bitpay/PrivateKey.php');
}

if (false === class_exists('Bitpay\PublicKey')) {
    include_once(__DIR__ . '/../../lib/Bitpay/PublicKey.php');
}

if (false === class_exists('Bitpay\Token')) {
    include_once(__DIR__ . '/../../lib/Bitpay/Token.php');
}

class xeniosPaymentModuleFrontController extends ModuleFrontController
{
	public $ssl = true;
	public $display_column_left = false;

	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
		parent::initContent();

		$cart = $this->context->cart;
		$ps_currency  = new Currency((int)($cart->id_currency));
		$currency_code = $ps_currency->iso_code;
		
		$notification_url = $this->context->link->getModuleLink('xenios', 'notification', [], true);
		
		
		$amount = number_format($cart->getOrderTotal(true, Cart::BOTH),2);
		$order_id = $cart->id;
		$customer = new Customer($cart->id_customer);
		$new_order_status = Configuration::get( 'XENIOS_NEWST' );
		
		
		$Xenios = new Xenios();
		
		$this->api_url = Configuration::get( 'XENIOS_URL' );
		$this->api_key = $Xenios->btcpay_decrypt(Configuration::get( 'XENIOS_KEY' ));
		
		
		$this->api_pub = $Xenios->btcpay_decrypt(Configuration::get( 'XENIOS_PUB' ));		
		$this->api_token = $Xenios->btcpay_decrypt(Configuration::get( 'XENIOS_TOKEN' ));
		$this->transaction_speed = Configuration::get( 'XENIOS_TRANSSPD' );
		
		$redirect_url = _PS_BASE_URL_.__PS_BASE_URI__.'index.php?controller=order-confirmation&id_cart='.(int)$this->context->cart->id.'&id_module='.(int)$Xenios->id.'&id_order='.(int)$order_id.'&key='.$this->context->customer->secure_key;
		

            $currency = new \Bitpay\Currency($currency_code);


            $client = new \Bitpay\Client\Client();

            if (false === isset($client) && true === empty($client)) {                
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not instantiate a client object. Cannot continue!');
            }
            $url = $this->api_url;
            $client->setUri($url);
            


            $curlAdapter = new \Bitpay\Client\Adapter\CurlAdapter();

            if (false === isset($curlAdapter) || true === empty($curlAdapter)) {
                   throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not instantiate a CurlAdapter object. Cannot continue!');
            }

            $client->setAdapter($curlAdapter);

            if (false === empty($this->api_key)) {
                $client->setPrivateKey($this->api_key);
            } else {
                
                throw new \Exception(' Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not set client->setPrivateKey to this->api_key. The empty() check failed!');
            }

            if (false === empty($this->api_pub)) {
                $client->setPublicKey($this->api_pub);
            } else {                
                throw new \Exception(' Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not set client->setPublicKey to this->api_pub. The empty() check failed!');
            }

            if (false === empty($this->api_token)) {
                $client->setToken($this->api_token);
            } else {
                
                throw new \Exception(' Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not set client->setToken to this->api_token. The empty() check failed!');
            }

            // Setup the Invoice
            $invoice = new \Bitpay\Invoice();

            if (false === isset($invoice) || true === empty($invoice)) {                
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not instantiate an Invoice object. Cannot continue!');
            } else {
             
            }

            $order_number = $order_id;
            $invoice->setOrderId((string)$order_number);
            $invoice->setCurrency($currency);
            $invoice->setFullNotifications(true);
            $invoice->setExtendedNotifications(true);

            // Add a priced item to the invoice
            $item = new \Bitpay\Item();

            if (false === isset($item) || true === empty($item)) {                
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not instantiate an item object. Cannot continue!');
            } else {
                
            }

            $order_total = $amount;
            if (true === isset($order_total) && false === empty($order_total)) {
                $order_total = (float)$order_total;
                if($order_total == 0 || $order_total === '0')
                    throw new \Bitpay\Client\ArgumentException("Price must be formatted as a float ". $order_total);
                $item->setPrice($order_total);
                //$taxIncluded = $order->get_cart_tax();
				$taxIncluded = 0;
                $item->setTaxIncluded($taxIncluded);
            } else {                
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not set item->setPrice to amount. The empty() check failed!');
            }
            // Add buyer's email to the invoice
            $buyer = new \Bitpay\Buyer();
            $buyer->setEmail($customer->email);
            $invoice->setBuyer($buyer);
            $invoice->setItem($item);

            // Add the Redirect and Notification URLs
            $invoice->setRedirectUrl($redirect_url);
            $invoice->setNotificationUrl($notification_url);
            $invoice->setTransactionSpeed($this->transaction_speed);  
            
            try {
                

                $invoice = $client->createInvoice($invoice);

                if (false === isset($invoice) || true === empty($invoice)) {                    
                    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a payment but could not instantiate an invoice object. Cannot continue!');
                } else {
                    
                }
            } catch (\Exception $e) {
                
                error_log($e->getMessage());
				throw new \Exception('Sorry, but Bitcoin checkout with Xenios Payments Cryptocurrency Gateway PrestaShop  does not appear to be working.');

            }


			$Xenios->validateOrder((int)$order_id, (int)$new_order_status, (float)$amount, $Xenios->displayName, null, array(), null, false, $cart->secure_key);
		
            header("location:".$invoice->getUrl());
		

            exit;
		
		
		//emd 
		
		

	}
	 
}
