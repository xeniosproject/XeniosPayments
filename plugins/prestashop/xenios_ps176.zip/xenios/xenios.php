<?php
/**
 * XENIOS
 */
use PrestaShop\PrestaShop\Core\Payment\PaymentOption; 

define("BTCPAY_VERSION", "0.0.1");
$autoloader_param = __DIR__ . '/lib/Bitpay/Autoloader.php';

if (!defined('_PS_VERSION_'))
    exit;

// Load up the BitPay library
if (true === file_exists($autoloader_param) &&
    true === is_readable($autoloader_param))
{
  if(false === class_exists("Bitpay\Autoloader")){
    require_once $autoloader_param;
    \Bitpay\Autoloader::register();
  }
} else {
    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was not installed correctly or the files are corrupt. Please make sure you have correct folder user rights and have all required PHP extensions installed');
}

// Exist for quirks in object serialization...
if (false === class_exists('Bitpay\PrivateKey')) {
    include_once(__DIR__ . '/lib/Bitpay/PrivateKey.php');
}

if (false === class_exists('Bitpay\PublicKey')) {
    include_once(__DIR__ . '/lib/Bitpay/PublicKey.php');
}

if (false === class_exists('Bitpay\Token')) {
    include_once(__DIR__ . '/lib/Bitpay/Token.php');
}


class Xenios extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'xenios';
        $this->tab = 'payments_gateways';
        $this->version = '1.75';
        $this->author = 'Xenios Payments Cryptocurrency Gateway PrestaShop';
        $this->need_instance = 1;
        $this->bootstrap = true;
		$this->ps_versions_compliancy = array('min' => '1.7.1.0', 'max' => _PS_VERSION_);
		$this->author = 'Xenios Payments Cryptocurrency Gateway PrestaShop';

        parent::__construct();

        $this->displayName = 'xenios';
        $this->description = $this->l('Secure payments with Xenios Payments Cryptocurrency Gateway PrestaShop.');	

    }

	
	public function install() {

		if ( ! parent::install() ||
		     ! $this->registerHook( 'paymentOptions' ) ||
		     ! $this->registerHook( 'orderConfirmation' ) ||
		     ! Configuration::updateValue( 'XENIOS_TITLE', 'Secure payments with Xenios Payments Cryptocurrency Gateway PrestaShop.' ) ||
		     ! Configuration::updateValue( 'XENIOS_ALIAS', null ) 

		) {
			return false;
		}

		return true;

	}	
	
	public function uninstall() {
		if ( ! parent::uninstall() ||
		     ! Configuration::deleteByName( 'XENIOS_TITLE' ) ||
		     ! Configuration::deleteByName( 'XENIOS_ALIAS' ) 
		) {
			return false;
		}

		return true;
	}
	
	
	public function getContent() {
		$output = null;

		if ( Tools::isSubmit( 'submit' . $this->name ) ) {
			
			if ($_REQUEST['revoke']) {
				Configuration::updateValue('XENIOS_KEY', '' );
				Configuration::updateValue('XENIOS_PUB', '');
				Configuration::updateValue('XENIOS_SIN', '');
				Configuration::updateValue('XENIOS_TOKEN', '');		
				Configuration::updateValue('XENIOS_LABEL', '' );				
				Configuration::updateValue('XENIOS_URL', '' );					
				Configuration::updateValue('XENIOS_PAIRCODE', '' );	
			}
			
			$urllist = array('https://api-demo.forgingblock.io', 'https://api.forgingblock.io');
			$xenios_title   = strval( Tools::getValue( 'XENIOS_TITLE' ) );
			$xenios_baseurl  = strval( Tools::getValue( 'XENIOS_BASEURL' ) );
			$xenios_parcode  = strval( Tools::getValue( 'XENIOS_PAIRCODE' ) );	

			if ($xenios_parcode) {
				if (!preg_match('/^[a-zA-Z0-9]{7}$/', $xenios_parcode)) {
					$output .= $this->displayError( $this->l( 'Invalid Pairing Code' ) );
                	return $output . $this->displayForm();                
            	}				
				
				else 					
				{
					$parcodeact =  $this->update_btcpay_pair_code($xenios_parcode, $urllist[$xenios_baseurl]);
					if ($parcodeact) {
						$output .= $this->displayError( $this->l( $parcodeact ) );
						return $output . $this->displayForm();                
					}
				}
				
				
			}

			if ( ! $xenios_title
			     || empty( $xenios_title )
			     || ! Validate::isGenericName( $xenios_title )			     			     
			) {
				$output .= $this->displayError( $this->l( 'Invalid Configuration.' ) );
			} else {
				Configuration::updateValue( 'XENIOS_TITLE', $xenios_title );
				Configuration::updateValue( 'XENIOS_BASEURL', $xenios_baseurl );							
				Configuration::updateValue( 'XENIOS_PAIRCODE', $xenios_parcode );
				
				Configuration::updateValue( 'XENIOS_TRANSSPD', strval( Tools::getValue( 'XENIOS_TRANSSPD' ) ));
				Configuration::updateValue( 'XENIOS_NEWST', strval( Tools::getValue( 'XENIOS_NEWST' ) ));
				Configuration::updateValue( 'XENIOS_PAIDST', strval( Tools::getValue( 'XENIOS_PAIDST' ) ));				
				Configuration::updateValue( 'XENIOS_CONFIRMRFST', strval( Tools::getValue( 'XENIOS_CONFIRMRFST' ) ));
				Configuration::updateValue( 'XENIOS_COMPLETEST', strval( Tools::getValue( 'XENIOS_COMPLETEST' ) ));
				Configuration::updateValue( 'XENIOS_INVALIDST', strval( Tools::getValue( 'XENIOS_INVALIDST' ) ));
				Configuration::updateValue( 'XENIOS_EXPIREDST', strval( Tools::getValue( 'XENIOS_EXPIREDST' ) ));				
				Configuration::updateValue( 'XENIOS_PAIDEXPIREDST', strval( Tools::getValue( 'XENIOS_PAIDEXPIREDST' ) ));
				Configuration::updateValue( 'XENIOS_PARTEXPIREDST', strval( Tools::getValue( 'XENIOS_PARTEXPIREDST' ) ));				
				
				
				$output .= $this->displayConfirmation( $this->l( 'Settings updated.' ) );
			}
		}

		return $output . $this->displayForm();
	}
	
	public function update_btcpay_pair_code($pairing_code, $url)
    {
        	

            // Generate Private Key
            $key = new \Bitpay\PrivateKey();

            if (true === empty($key)) {
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a pairing code but could not instantiate a PrivateKey object. Cannot continue!');
            }

            $key->generate();

            // Generate Public Key
            $pub = new \Bitpay\PublicKey();

            if (true === empty($pub)) {
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a pairing code but could not instantiate a PublicKey object. Cannot continue!');
            }

            $pub->setPrivateKey($key);
            $pub->generate();

            // Get SIN Format
            $sin = new \Bitpay\SinKey();

            if (true === empty($sin)) {
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a pairing code but could not instantiate a SinKey object. Cannot continue!');
            }

            $sin->setPublicKey($pub);
            $sin->generate();

            // Create an API Client
            $client = new \Bitpay\Client\Client();

            if (true === empty($client)) {
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a pairing code but could not instantiate a Client object. Cannot continue!');
            }
            $client->setUri($url);
            $curlAdapter = new \Bitpay\Client\Adapter\CurlAdapter();

            if (true === empty($curlAdapter)) {
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to process a pairing code but could not instantiate a CurlAdapter object. Cannot continue!');
            }

            $client->setAdapter($curlAdapter);

            $client->setPrivateKey($key);
            $client->setPublicKey($pub);

            // Sanitize label
            
            $label = 'PrestaShop';

            try {
                $token = $client->createToken(
                    array(
                        'id'          => (string) $sin,
                        'pairingCode' => $pairing_code,
                        'label'       => $label,
                    )
                );
            } catch (\Exception $e) {                
                return $e->getMessage();
            }

			Configuration::updateValue('XENIOS_KEY', $this->btcpay_encrypt($key) );
			Configuration::updateValue('XENIOS_PUB', $this->btcpay_encrypt($pub) );
			Configuration::updateValue('XENIOS_SIN', (string)$sin );		
			Configuration::updateValue('XENIOS_TOKEN', $this->btcpay_encrypt($token) );		
			Configuration::updateValue('XENIOS_LABEL', $label );				
			Configuration::updateValue('XENIOS_URL', $url );	
            
        
    }
	
	public function btcpay_encrypt($data)
        {
            if (false === isset($data) || true === empty($data)) {
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to encrypt data but no data was passed!');
            }

            

            $openssl_ext = new \Bitpay\Crypto\OpenSSLExtension();
            $fingerprint = sha1(sha1(__DIR__));

            if (true === isset($fingerprint) &&
                true === isset($openssl_ext)  &&
                strlen($fingerprint) > 24)
            {
                $fingerprint = substr($fingerprint, 0, 24);

                if (false === isset($fingerprint) || true === empty($fingerprint)) {
                    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to encrypt data but could not generate a fingerprint parameter!');
                }

                $encrypted = $openssl_ext->encrypt(base64_encode(serialize($data)), $fingerprint, '1234567890123456');

                if (true === empty($encrypted)) {
                    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to encrypt a serialized object and failed!');
                }



                return $encrypted;
            } else {
                
                wp_die('Invalid server fingerprint generated');
            }
        }

	
	public function btcpay_decrypt($encrypted)
        {
            if (false === isset($encrypted) || true === empty($encrypted)) {
                throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to decrypt data but no data was passed!');
            }

            
         
            $openssl_ext = new \Bitpay\Crypto\OpenSSLExtension();

            $fingerprint = sha1(sha1(__DIR__));

            if (true === isset($fingerprint) &&
                true === isset($openssl_ext)  &&
                strlen($fingerprint) > 24)
            {
                $fingerprint = substr($fingerprint, 0, 24);

                if (false === isset($fingerprint) || true === empty($fingerprint)) {
                    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to decrypt data but could not generate a fingerprint parameter!');
                }

                $decrypted = base64_decode($openssl_ext->decrypt($encrypted, $fingerprint, '1234567890123456'));

                // Strict base64 char check
                if (false === base64_decode($decrypted, true)) {
                    
                } else {
                    $decrypted = base64_decode($decrypted);
                }

                if (true === empty($decrypted)) {
                    throw new \Exception('Xenios Payments Cryptocurrency Gateway PrestaShop payment plugin was called to unserialize a decrypted object and failed! The decrypt function was called with "' . $encrypted . '"');
                }

                

                return unserialize($decrypted);
            } else {
                
                wp_die('Invalid server fingerprint generated');
            }
      
    }
	
	protected function displayForm() {
		// Get default language
		$default_lang = (int) Configuration::get( 'PS_LANG_DEFAULT' );
		
		$xenios_label = Configuration::get( 'XENIOS_LABEL' ) ;		
		if (Configuration::get('XENIOS_TOKEN' ) )
		 $xenios_token  =  $this->btcpay_decrypt(Configuration::get('XENIOS_TOKEN' ) );
		
		$urls_list[] = array('id' => '0' , 'url' => 'https://api-demo.forgingblock.io');
		$urls_list[] = array('id' => '1' , 'url' => 'https://api.forgingblock.io');
		
		
		$transspd[] = array('id' => 'default' , 'name' => 'Keep store level configuration');		
		$transspd[] = array('id' => 'high' , 'name' => '0 confirmation on-chain');		
		$transspd[] = array('id' => 'medium' , 'name' => '1 confirmation on-chain');				
		$transspd[] = array('id' => 'low-medium' , 'name' => '2 confirmations on-chain');
		$transspd[] = array('id' => 'low' , 'name' => '6 confirmations on-chain');		

		// Init Fields form array
		$fields_form[1]['form'] = array(
			'legend' => array(
				'title' => $this->l( 'Settings' ),
			),
			'input'  => array(
				array(
					'type'     => 'text',
					'label'    => $this->l( 'Title' ),
					'name'     => 'XENIOS_TITLE',
					'size'     => 50,
					'required' => true
				),
				array(
					'type' => 'select',
					'label'    => $this->l( 'Invoice pass to "confirmed" state after' ),
					'name'     => 'XENIOS_TRANSSPD',					
						'options' => array(
                            'query' => $transspd,
                            'id' => 'id',
                            'name' => 'name',
                        ),
					'required' => true
				),	
				
			),
			
		);
		if ($xenios_token) {
			$fields_form[2]['form'] = array(
			'legend' => array(
				'title' => $this->l( 'Token' ),
			),
			'input'  => array(							
				array(
					'type'     => 'label',
					'label'    => $this->l( 'ID' ),					
					'desc'    => $xenios_token,					
				),
				
				array(
					'type'     => 'label',
					'label'    => $this->l( 'Label' ),					
					'desc'    => $xenios_label,					
				),				
					
			),
					
			'submit' => array(
				'title' => $this->l( 'Revoke' ),
				'name' => 'revoke',				
				'class' => 'btn btn-default pull-right'
			)
		);
			
		}
		else {
		$fields_form[2]['form'] = array(
			'legend' => array(
				'title' => $this->l( 'Token' ),
			),
			'input'  => array(				
				array(
					'type' => 'select',
					'label'    => $this->l( 'API URL' ),
					'name'     => 'XENIOS_BASEURL',					
					'options' => array(
                            'query' => $urls_list,
                            'id' => 'id',
                            'name' => 'url',
                        ),
					'required' => true
				),
				array(
					'type'     => 'text',
					'label'    => $this->l( 'Pairing Code' ),
					'name'     => 'XENIOS_PAIRCODE',
					'size'     => 32,
					'required' => true
				),
			),
			'submit' => array(
				'title' => $this->l( 'Pair' ),
				'class' => 'btn btn-default pull-right'
			)
		);
		}
		
		$states = 	OrderState::getOrderStates((int) Configuration::get('PS_LANG_DEFAULT'));
		foreach ($states as $state)				
			$OrderStates[$state['id_order_state']] = $state['name'];
		
		
		$fields_form[3]['form'] = array(
			'legend' => array(
				'title' => $this->l( 'Order Status' ),
			),
			'input'  => array(				
				array(
					'type' => 'select',
					'label'    => $this->l( 'New Order' ),
					'name'     => 'XENIOS_NEWST',					
						'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),
					'required' => true
				),				
				
				array(
					'type' => 'select',
					'label'    => $this->l( 'Paid' ),
					'name'     => 'XENIOS_PAIDST',										
					'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),					
					'required' => true
				),	
				
				array(
					'type' => 'select',
					'label'    => $this->l( 'Confirmed' ),
					'name'     => 'XENIOS_CONFIRMRFST',										
					'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),					
					'required' => true
				),
				
				array(
					'type' => 'select',
					'label'    => $this->l( 'Complete' ),
					'name'     => 'XENIOS_COMPLETEST',										
					'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),					
					'required' => true
				),
				array(
					'type' => 'select',
					'label'    => $this->l( 'Invalid' ),
					'name'     => 'XENIOS_INVALIDST',										
					'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),					
					'required' => true
				),
				array(
					'type' => 'select',
					'label'    => $this->l( 'Expired' ),
					'name'     => 'XENIOS_EXPIREDST',										
					'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),					
					'required' => true
				),
				
				array(
					'type' => 'select',
					'label'    => $this->l( 'Paid after expiration' ),
					'name'     => 'XENIOS_PAIDEXPIREDST',										
					'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),					
					'required' => true
				),
				array(
					'type' => 'select',
					'label'    => $this->l( 'Expired with partial payment' ),
					'name'     => 'XENIOS_PARTEXPIREDST',										
					'options' => array(
                            'query' => $states,
                            'id' => 'id_order_state',
                            'name' => 'name',
                        ),					
					'required' => true
				),
				
				
			),
			'submit' => array(
				'title' => $this->l( 'Save' ),
				'class' => 'btn btn-default pull-right'
			)
		);
		

		$helper = new HelperForm();

		// Module, token and currentIndex
		$helper->module          = $this;
		$helper->name_controller = $this->name;
		$helper->token           = Tools::getAdminTokenLite( 'AdminModules' );
		$helper->currentIndex    = AdminController::$currentIndex . '&configure=' . $this->name;

		// Language
		$helper->default_form_language    = $default_lang;
		$helper->allow_employee_form_lang = $default_lang;

		// Title and toolbar
		$helper->title          = $this->displayName;
		$helper->show_toolbar   = true;        // false -> remove toolbar
		$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
		$helper->submit_action  = 'submit' . $this->name;
		$helper->toolbar_btn    = array(
			'save' =>
				array(
					'desc' => $this->l( 'Save' ),
					'href' => AdminController::$currentIndex . '&configure=' . $this->name . '&save' . $this->name .
					          '&token=' . Tools::getAdminTokenLite( 'AdminModules' ),
				),
			'back' => array(
				'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite( 'AdminModules' ),
				'desc' => $this->l( 'Back to list' )
			)
		);

		// Load current value
		$helper->fields_value['XENIOS_TITLE']       = Configuration::get( 'XENIOS_TITLE' );
		$helper->fields_value['XENIOS_PAIRCODE']  = Configuration::get( 'XENIOS_PAIRCODE' );
		$helper->fields_value['XENIOS_APIBASEURL']  = Configuration::get( 'XENIOS_APIBASEURL' );		
		
		$helper->fields_value['XENIOS_TRANSSPD']  = Configuration::get( 'XENIOS_TRANSSPD' );	
		
		$helper->fields_value['XENIOS_NEWST']  = empty(Configuration::get( 'XENIOS_NEWST' )) ? 3 : Configuration::get( 'XENIOS_NEWST' );		
		$helper->fields_value['XENIOS_PAIDST']  = empty(Configuration::get( 'XENIOS_PAIDST' )) ? 11 : Configuration::get( 'XENIOS_PAIDST' );				
		$helper->fields_value['XENIOS_CONFIRMRFST']  = empty(Configuration::get( 'XENIOS_CONFIRMRFST' )) ? 2 : Configuration::get( 'XENIOS_CONFIRMRFST' );			
		$helper->fields_value['XENIOS_COMPLETEST']  = empty(Configuration::get( 'XENIOS_COMPLETEST' )) ? 2 : Configuration::get( 'XENIOS_COMPLETEST' );			
		$helper->fields_value['XENIOS_INVALIDST']  = empty(Configuration::get( 'XENIOS_INVALIDST' )) ? 8 : Configuration::get( 'XENIOS_INVALIDST' );		
		$helper->fields_value['XENIOS_EXPIREDST']  = empty(Configuration::get( 'XENIOS_EXPIREDST' )) ? 8 : Configuration::get( 'XENIOS_EXPIREDST' );				
		$helper->fields_value['XENIOS_PAIDEXPIREDST']  = empty(Configuration::get( 'XENIOS_PAIDEXPIREDST' )) ? 8 : Configuration::get( 'XENIOS_PAIDEXPIREDST' );
		$helper->fields_value['XENIOS_PARTEXPIREDST']  = empty(Configuration::get( 'XENIOS_PARTEXPIREDST' )) ? 8 : Configuration::get( 'XENIOS_PARTEXPIREDST' );		

		

		return $helper->generateForm( $fields_form );
	}	
	
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        $payment_options = [
            $this->XeniosExternalPaymentOption(),
        ];
        return $payment_options;
    }	

   
	

    public function XeniosExternalPaymentOption()
    {		
		if (isset($_GET['XeniosPaymenterror'])) $errmsg = $_GET['XeniosPaymenterror'];	
		
		$this->context->smarty->assign( array(
			'this_path'     => $this->_path,
			'this_path_bw'  => $this->_path,
            'errmsg' => $errmsg,									
			'this_path_ssl' => Tools::getShopDomainSsl( true, true ) . __PS_BASE_URI__ . 'modules/' . $this->name . '/',
			'xenios_title'  => Configuration::get( 'XENIOS_TITLE' )
		) );

		

		$paymentController = $this->context->link->getModuleLink($this->name,'payment',array(),true);

        $newOption = new PaymentOption();
        $newOption->setCallToActionText($this->l('Pay with Xenios'))
			->setAction($paymentController)
            ->setAdditionalInformation($this->context->smarty->fetch('module:xenios/views/templates/front/payment_infos.tpl'));

        return $newOption;
    }

	
		
    public static function setOrderStatus($oid, $status)
    {
		
		$order = new Order((int)Order::getOrderByCartId($oid));
		$new_history = new OrderHistory();
        $new_history->id_order = (int)$order->id;        
        $new_history->changeIdOrderState((int)$status, $order, true);
        $new_history->addWithemail(true);
		  
    }
	



}
