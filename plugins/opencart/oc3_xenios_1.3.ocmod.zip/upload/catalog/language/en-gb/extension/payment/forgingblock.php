<?php

$_['text_title'] = 'Xenios Payments Cryptocurrency Gateway OpenCart secured payment';
$_['text_test'] = 'Xenios Payments Cryptocurrency Gateway OpenCart target environment is <b>Test Mode</b>. Your account will not be charged.';
$_['text_transaction'] = 'Payment transaction ID : ';

// ERROR
$_['heading_title'] = 'Xenios Payments Cryptocurrency Gateway OpenCart error';
$_['payment_refused'] = 'Your payment is refused';
$_['forgingblock_error'] = 'An error occured when calling Xenios Payments Cryptocurrency Gateway OpenCart';

?>