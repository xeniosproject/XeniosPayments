<?php

require_once(DIR_SYSTEM.'library/forgingblock/lib/Forgingblock.php');

class ControllerExtensionPaymentForgingblock extends Controller {
	
	var $forgingblockTrace, $errorMessage;
	

	
	public function index() {
		$this->load->model('checkout/order');
		$this->language->load('extension/payment/forgingblock');
		$data['button_confirm'] = $this->language->get('button_confirm');
		$data['action'] = HTTP_SERVER.'index.php?route=extension/payment/forgingblock/doPayment';
		$data['forgingblock_production'] = $this->config->get('payment_forgingblock_production');
		$data['text_test'] = $this->language->get('text_test');
		
		$this->load->model('checkout/order');		
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);						

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/extension/payment/forgingblock')) {
			//$this->template = $this->config->get('config_template') . '/template/extension/payment/forgingblock';
			return $this->load->view($this->config->get('config_template') . '/extension/payment/forgingblock', $data);
		} else {
			//$this->template = 'default/template/extension/payment/forgingblock';
			return $this->load->view('/extension/payment/forgingblock', $data);
		}
		//$this->render();
	}

	
		
	public function callback() {
		$this->language->load('extension/payment/forgingblock');
		
				
		$order_id = $_GET['orderid'];
		$this->load->model('checkout/order');
		$this->load->model('setting/setting');		
		$order_info = $this->model_checkout_order->getOrder($order_id);	
		$payment_custom_field = $order_info['payment_custom_field'];
		$invoice_id =  $payment_custom_field['invoice_id'] ;
		
		
		if (empty($invoice_id)) {
			$this->display_error_page(2,'Invoice No Not Found');						
			return ;
		}
		
		
		$trmode = ($this->config->get('payment_forgingblock_production') == '1') ? 'live' : 'test';		
		
		$forgingblock = new Forgingblock($trmode);
		$forgingblock->SetValue('trade', $this->config->get('payment_forgingblock_trade_id'));
		$forgingblock->SetValue('token', $this->config->get('payment_forgingblock_token'));		
		$forgingblock->SetValue('invoice', $invoice_id);		
		
		$resar = $forgingblock->CheckInvoiceStatus();
		
		$payment_status = $forgingblock->GetInvoiceStatus();
		
		if (isset($payment_status)) {			
			$comment = $payment_status;
			$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_forgingblock_'.$payment_status.'_status_id'), $comment);
			if($_GET['action'] != 'notify') $this->response->redirect(HTTP_SERVER.'index.php?route=checkout/success');
			exit;
		}
		else {
			$this->display_error_page(2,'Unknown Payment Status');
			return ;
		}
		
	}
	
	
	public function doPayment() {
		$this->language->load('extension/payment/forgingblock');
        $this->load->model('setting/setting');
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);				
		$comment = 'new';
		
		$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('payment_forgingblock_new_status_id'), $comment);
		$trmode = ($this->config->get('payment_forgingblock_production') == '1') ? 'live' : 'test';
		
		
		$returnURL = HTTP_SERVER.'index.php?route=checkout/success';
		$notifyURL = HTTP_SERVER.'index.php?route=extension/payment/forgingblock/callback&action=notify&orderid='.$this->session->data['order_id'];
		
		
		
		
		$forgingblock = new Forgingblock($trmode);
		$forgingblock->SetValue('trade', $this->config->get('payment_forgingblock_trade_id'));
		$forgingblock->SetValue('token', $this->config->get('payment_forgingblock_token'));
		$forgingblock->SetValue('amount', round($order_info['total'], 2));								
		$forgingblock->SetValue('currency', $order_info['currency_code']);		
		$forgingblock->SetValue('link', $returnURL);
		$forgingblock->SetValue('notification', $notifyURL);
		$forgingblock->SetValue('order', $this->session->data['order_id']);		
		$resar = $forgingblock->CreateInvoice();
		
		
		$Error = $forgingblock->GetError();
		
		
		if ($Error) {
			$this->display_error_page(1,$Error);
		}
		else {
			$paymenturl = $forgingblock->GetInvoiceURL();
			$InvoiceID = $forgingblock->GetInvoiceID();	
			$this->UpdateInvoiceID($this->session->data['order_id'], $InvoiceID);	
			$this->response->redirect($paymenturl);
			exit;
		}		
		
	}
	
	
	public function display_error_page($type,$errorMessage){

		$this->language->load('extension/payment/forgingblock');
		$this->load->model('setting/setting');
		$this->document->setTitle($this->language->get('heading_title'));
		
			$data['header'] = $this->load->controller('common/header');		
			$data['column_content_bottom'] = $this->load->controller('common/content_bottom');
			$data['column_content_top'] = $this->load->controller('common/content_top');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['footer'] = $this->load->controller('common/footer');
		

		if($type == 1){
			$data['heading_title'] = $this->language->get('forgingblock_error');
		}else if ($type == 2){
			$data['heading_title'] = $this->language->get('payment_refused');
		}
		$data['text_error'] = $errorMessage;
		$data['button_continue'] = $this->language->get('button_continue');
		$data['continue'] = $this->url->link('common/home');
		

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/extension/error/forgingblock')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/extension/error/forgingblock', $data));
		} else {
			$this->response->setOutput($this->load->view('/extension/error/forgingblock', $data));
		}
	}
	
	private function UpdateInvoiceID($order_id, $invoice_id){
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$payment_custom_field = $order_info['payment_custom_field'];
		$payment_custom_field['invoice_id'] = $invoice_id;
		$this->db->query("UPDATE `" . DB_PREFIX . "order` SET payment_custom_field = '" . $this->db->escape(json_encode($payment_custom_field)) .  "', date_modified = NOW() WHERE order_id = '" . (int)$order_id . "'");
	}
}
?>