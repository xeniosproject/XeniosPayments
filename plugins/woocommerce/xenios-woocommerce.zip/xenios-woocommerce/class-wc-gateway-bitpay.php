<?php 
    require_once __DIR__ ."/class-wc-gateway-btcpay.php" 
?>